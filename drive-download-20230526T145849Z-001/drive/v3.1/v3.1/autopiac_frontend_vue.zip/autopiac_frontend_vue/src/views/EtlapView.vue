<template>
  <div class="home">
    <Favourites msg="Heti kedvencek" />
    <Products title="Pizzáink" />
  </div>
</template>

<script>
// @ is an alias to /src

import Favourites from '@/components/Favourites.vue'
import Products from '@/components/Products.vue'

export default {
  name: 'EtlapView',
  components: {
    Favourites,
    Products
  }
}
</script>