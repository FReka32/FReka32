<template>
  <div class="login">
    <!--h1>Login page</h1-->
    <!--div class="modal modal-sheet position-static d-block py-5 !--bg-secondary--" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-warning">
            <h5 v-if="!logged" class="modal-title" id="loginModalLabel">
              Bejelentkezés
            </h5>
            <h5 v-if="logged" class="modal-title" id="loginModalLabel">
              Kijelentkezés
            </h5>
            <button type="button" class="btn-close" @click="closeClick()"></button>
          </div>
          <div class="modal-body">
            <div v-if="!logged" class="input group mb-3">
              <span class="input-group-text">Név:</span>
              <input type="text" class="form-control" v-model="FelhasznaloNeve"/>
            </div>
            <div v-if="!logged" class="input group mb-3">
              <span class="input-group-text">Jelszó:</span>
              <input type="password" class="form-control" v-model="Password"/>
            </div>
            <button type="button" @click="loginClick(FelhasznaloNeve,Password)" v-if="!logged" class="btn btn-primary m-2 float-end">
              Bejelentkezés
            </button>
          </div>
        </div>
      </div>
    </div-->
    <div
      class="modal modal-signin position-static d-block bg-secondary py-5"
      tabindex="-1"
      role="dialog"
      id="modalSignin"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content rounded-4 shadow">
          <div class="modal-header p-5 pb-4 border-bottom-0">
            <!-- <h1 class="modal-title fs-5" >Modal title</h1> -->
            <h1 v-if="!logged" class="fw-bold mb-0 fs-2">Bejelentkezés</h1>
            <h1 v-else class="fw-bold mb-0 fs-2">Kijelentkezés</h1>
            <!--button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button-->
            <button
              type="button"
              class="btn-close"
              @click="closeClick()"
            ></button>
          </div>

          <div class="modal-body p-5 pt-0">
            <form class="">
              <div v-if="!logged">
                <div class="form-floating mb-3">
                  <input
                    type="text"
                    class="form-control rounded-3"
                    id="floatingInput"
                    placeholder="UserName"
                    v-model="FelhasznaloNeve"
                  />
                  <label for="floatingInput">Felhasználónév</label>
                </div>
                <div class="form-floating mb-3">
                  <input
                    type="password"
                    class="form-control rounded-3"
                    id="floatingPassword"
                    placeholder="Password"
                    v-model="Password"
                  />
                  <label for="floatingPassword">Jelszó</label>
                </div>
              </div>
              <button
                v-if="!logged"
                class="w-100 mb-2 btn btn-lg rounded-3 btn-primary"
                type="button"
                @click="loginClick(FelhasznaloNeve, Password)"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  class="bi bi-box-arrow-in-right"
                  viewBox="0 0 16 16"
                >
                  <path
                    fill-rule="evenodd"
                    d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"
                  />
                  <path
                    fill-rule="evenodd"
                    d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"
                  />
                </svg>
                Bejelentkezés
              </button>
              <button
                v-else
                class="w-100 mb-2 btn btn-lg rounded-3 btn-primary"
                type="button"
                @click="logoutClick()"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  class="bi bi-box-arrow-right"
                  viewBox="0 0 16 16"
                >
                  <path
                    fill-rule="evenodd"
                    d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"
                  />
                  <path
                    fill-rule="evenodd"
                    d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"
                  />
                </svg>
                Kijelentkezés
              </button>
              <small v-if="!logged" class="text-muted"
                >Bejelentkezés az adatkarbantartási felületre.</small
              >
              <small v-else class="text-muted"
                >Kijelentkezés az adatkarbantartási felületről.</small
              >
              <hr class="my-4" />
              <h2 class="fs-5 fw-bold mb-3">További lehetőségek</h2>
              <div v-if="!logged">
                <button
                  class="w-100 py-2 mb-2 btn btn-outline-primary rounded-3"
                  type="submit"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-person-add"
                    viewBox="0 0 16 16"
                  >
                    <path
                      d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"
                    />
                    <path
                      d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"
                    />
                  </svg>
                  Regisztráció
                </button>
                <button
                  class="w-100 py-2 mb-2 btn btn-outline-secondary rounded-3"
                  type="submit"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-unlock"
                    viewBox="0 0 16 16"
                  >
                    <path
                      d="M11 1a2 2 0 0 0-2 2v4a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h5V3a3 3 0 0 1 6 0v4a.5.5 0 0 1-1 0V3a2 2 0 0 0-2-2zM3 8a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1H3z"
                    />
                  </svg>
                  Elfelejtett jelszó
                </button>
              </div>
              <div v-else>
                <button
                  class="w-100 py-2 mb-2 btn btn-outline-primary rounded-3"
                  type="submit"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-person-add"
                    viewBox="0 0 16 16"
                  >
                    <path
                      d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"
                    />
                    <path
                      d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"
                    />
                  </svg>
                  Jelszó megváltoztatása
                </button>
              </div>
              <!--button class="w-100 py-2 mb-2 btn btn-outline-warning rounded-3" type="submit">
            <svg class="bi me-1" width="16" height="16"><use xlink:href="#github"/></svg>
            Jelszó csere
          </button-->
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import sha256 from "sha256";

export default {
  name: "LoginView",
  components: {},

  data() {
    return {
      FelhasznaloNeve: "",
      Password: "",
      logged: this.$store.state.logged,
    };
  },

  methods: {
    closeClick() {
      this.$router.push("/");
    },
    logoutClick() {
      let url = "https://localhost:5001/Logout/" + this.$store.state.Uid;
      console.log(url);
      axios
        .post(url)
        .then((response) => {
          if (response.status == 200) {
            this.$store.state.logged = false;
            this.$store.state.Uid = "";
            this.$store.state.teljesNev = "";
            this.$store.state.jogosultsag = 0;
            alert(response.data);
            document.getElementById("loginButton").innerHTML = "Login";
          } else {
            alert(response.data);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    loginClick(FelhasznaloNeve, Password) {
      axios
        .post("https://localhost:5001/Login/SaltRequest/" + FelhasznaloNeve)
        .then((response) => {
          let lekertSalt = response.data;
          console.log(lekertSalt);
          let tmpHash = sha256(Password + lekertSalt).toString();
          let url =
            "https://localhost:5001/Login?nev=" +
            FelhasznaloNeve +
            "&tmpHash=" +
            tmpHash;
          axios
            .post(url)
            .then((response) => {
              this.$store.state.Uid = response.data[0];
              this.$store.state.userName = response.data[1];
              this.$store.state.jogosultsag = response.data[2];
              console.log(this.$store.state.Uid);
              console.log(this.$store.state.userName);
              console.log(this.$store.state.jogosultsag);
              if (response.status == 200) {
                this.$store.state.logged = true;
                this.refreshData();
                this.closeClick();
                alert("Sikeres bejelentkezés: " + this.$store.state.userName);
              } else {
                alert(this.$store.state.Uid);
              }
            })
            .catch((error) => {
              alert("Hiba történt:\n" + error.message);
            });
        })
        .catch((error) => {
          console.log(error);
          alert("Hiba történt:\n" + error.message);
        });
    },
    refreshData() {
      if (this.$store.state.logged) {
        document.getElementById("loginButton").innerHTML = "Logout";
      } else {
        document.getElementById("loginButton").innerHTML = "Login";
      }
    },
  },
};
</script>

<style scoped>
.login {
  background-color: white;
}
</style>
