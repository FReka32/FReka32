<template>
  <div>
    <router-link id="loginButton" class="btn btn-light btn-outline-primary float-end" to="/Login">
      Login
    </router-link>
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/felhasznalok">Felhasználók</router-link>
    </nav>
    <router-view></router-view>
  </div>
</template>

<style>
#loginButton{
  margin-right: 30px;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  margin-top: 30px;
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
