﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using WebAppPiac.Models;


namespace WebAppPiac.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class GyumolcsController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            using (MyDatabaseContext context = new MyDatabaseContext())
            {
                try
                {
                    List<Gyumolcs> gyumolcsok = new List<Gyumolcs>(context.Gyumolcs.ToList());
                    return Ok(gyumolcsok);
                }
                catch (Exception ex)
                {
                    return StatusCode(400, ex.Message);
                }
            }
        }

        [HttpPost]
        public IActionResult Post(Gyumolcs gyumolcs)
        {
            using (MyDatabaseContext context = new MyDatabaseContext())
            {
                try
                {
                    context.Gyumolcs.Add(gyumolcs);
                    context.SaveChanges();
                    return StatusCode(201, "A gyümölcs hozzáadása sikeresen megtörtént.");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }
        [HttpPut]
        public string Put(Gyumolcs gyumolcs)
        {
            using (MyDatabaseContext context = new MyDatabaseContext())
            {
                try
                {

                    context.Gyumolcs.Update(gyumolcs);
                    context.SaveChanges();
                    return $"A(z) {gyumolcs.Nev} gyümölcs módosítása sikeresen megtörtént.";
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
            }
        }

        [HttpDelete]
        public string Delete(int Id)
        {
            using (MyDatabaseContext context = new MyDatabaseContext())
            {
                try
                {
                    Gyumolcs gyumolcs = new Gyumolcs();
                    gyumolcs.Id = Id;
                    context.Gyumolcs.Remove(gyumolcs);
                    context.SaveChanges();
                    return $"A(z) '{Id}' azonosítójú gyümölcs törlése sikeresen megtörtént.";
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
            }
        }
    }
}
