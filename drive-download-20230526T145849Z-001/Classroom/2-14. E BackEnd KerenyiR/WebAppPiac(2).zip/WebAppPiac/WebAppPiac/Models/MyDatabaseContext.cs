﻿using Microsoft.EntityFrameworkCore;

namespace WebAppPiac.Models
{
    public class MyDatabaseContext:DbContext
    {
        public MyDatabaseContext(DbContextOptions<MyDatabaseContext> options):base (options)
        {
        }
        public DbSet<Gyumolcs> Gyumolcs { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
}
