﻿namespace WebAppPiac.Models
{
    public class Gyumolcs
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public int Ar { get; set; }
        public byte Minoseg { get; set; }
        public string KepUtvonala { get; set; }
    }
}
