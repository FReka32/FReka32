function GenerateSalt()
{
    let salt=""
    let possible="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    for (let i=0;i<64;i++)
    {
        salt+=possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return salt
}

let lekertSalt = "";
let password="a";
let nev="a"; 
let salt=GenerateSalt();
//salt="XDNRw5XBEGBXDBmBktxeYlzOG7emYhghbpnJLqv75kf4bPeE8v7wQCgvN9Kybvnh"
salt = "dkBczmjgWSy0aujs7sjUppKkICH17L0eYo2XGYUCmOp9Dia1uWrsCDjyZaUxeriL";
let hash=CryptoJS.SHA256(CryptoJS.SHA256(password+salt).toString()).toString();
console.log(password);
console.log(salt);
console.log(hash);
axios.post("https://localhost:5001/Login/SaltRequest/"+nev).then((response)=>{
    lekertSalt = response.data;
    console.log(response.data);
    let tmpHash = CryptoJS.SHA256(password+lekertSalt).toString();
    console.log(tmpHash);
    let url = "https://localhost:5001/Login?nev="+nev+"&tmpHash="+tmpHash;
    console.log(url);
    axios.post(url).then=((response)=> {
        tomb = response.data;
        console.log(tomb[0]);
    })
});