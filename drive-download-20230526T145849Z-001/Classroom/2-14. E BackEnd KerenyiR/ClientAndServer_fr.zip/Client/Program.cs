﻿using System;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpClient client=new TcpClient("localhost",50000);
            StreamReader r=new StreamReader(client.GetStream(), Encoding.UTF8);
            StreamWriter w=new StreamWriter(client.GetStream(), Encoding.UTF8);
            bool vege=false;
            string message=r.ReadLine();
            System.Console.WriteLine(message);
            while (!vege)
            {
                string command=Console.ReadLine();
                w.WriteLine(command);
                w.Flush();
                message=r.ReadLine();
                System.Console.WriteLine(message);
                if (message=="Bye!") 
                {
                    vege=true;
                }
            }
        }
    }
}
