using System;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.IO;
using System.Text;

namespace ClientAndServer 
{
    class ClientCom
    {
        private StreamReader r=null;
        private StreamWriter w=null;
        public ClientCom(TcpClient client)
        {
            r=new StreamReader(client.GetStream(), Encoding.UTF8);
            w=new StreamWriter(client.GetStream(), Encoding.UTF8);
        }
        public void CommStart()
        {
            w.WriteLine("Szerver neve:Elsö szerverem......");
            w.Flush();
            bool vege=false;
            while (!vege)
            {
                string command=r.ReadLine();
                string[] parameters=command.Split("|");
                switch (parameters[0])
                {
                    case "BYE":
                    {
                        vege=true;
                        w.WriteLine("Bye!");
                        Disconnect();
                        break;
                    }
                    case "OSSZE":
                    {
                        w.WriteLine(Osszeadas(double.Parse(parameters[1]),double.Parse(parameters[2])));
                        break;
                    }
                    default:
                    {
                        w.WriteLine("Error . Hibás utasítás!");
                        break;
                    }
                }
                w.Flush();
            }
        }

        void Disconnect()
        {
            Console.WriteLine("Kliens lecsatlakozott....");
        }

        private double Osszeadas(double a,double b)
        {
            return a+b;
        } 
    }
}