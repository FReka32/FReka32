<template>
  <div class="felhasznalok">
    <HelloWorld msg="Felhasználók adatai"/>
  </div>
</template>
<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'FelhasznalokView',
  components: {
    HelloWorld
  }
}
</script>

<style scoped>
.felhasznalok {
  background-color: lavender;
}
</style>
