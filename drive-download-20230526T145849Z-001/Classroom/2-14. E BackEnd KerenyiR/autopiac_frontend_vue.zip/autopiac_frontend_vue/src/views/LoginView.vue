<template>
  <div class="login">
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true" role="dialog">
      <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-primary">
            <h5 v-if="!logged" class="modal-title" id="loginModalLabel" aria-labelledby="loginModal">Bejelentkezés</h5>
            <h5 v-if="logged" class="modal-title" id="loginModalLabel" aria-labelledby="loginModal">Kijelentkezés</h5>
            <button type="button" class="btn btn-close" @click="closeClick()"></button>
          </div>
          <div class="modal-body">
            <div v-if="!logged" class="input group mb-3">  
              <span class="input-group-text">Név:</span>
              <input type="text" class="form-control" v-model="FelhasznaloNeve">
            </div>
            <div v-if="!logged" class="input group mb-3">  
              <span class="input-group-text">Jelszó:</span>
              <input type="password" class="form-control" v-model="Password">
            </div>
            <button type="button" @click="loginClick(FelhasznaloNeve, Password)" v-if="!logged" class="btn btn-primary m-2 float-end">Bejelentkezés</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'
import bootstrap from "bootstrap/dist/js/bootstrap.min.js";
import axios from "axios";
import sha256 from "sha256";

export default {
  name: 'LoginView',
  components: {},
  data(){
    return {
      FelhasznaloNeve: "",
      Password: "",
      logged:this.$store.state.logged,
    }
  },
  mounted() {
        this.openViewer();
    },
  methods:{
    closeClick() {
      this.$router.push("/")
      myModal.hide();
    },
    loginClick(FelhasznaloNeve, Password) {
      axios.post("https://localhost:5001/Login/SaltRequest/"+FelhasznaloNeve).then((response)=>{
        let lekertSalt=response.data;
        console.log(response.data);
        let tmpHash=CryptoJS.SHA256(Password+lekertSalt).toString();
        console.log(tmpHash)
        let url="https://localhost:5001/Login?nev="+FelhasznaloNeve+"&tmpHash="+tmpHash
        axios.post(url).then((response)=>{
            this.$store.state.Uid=response.data[0];
            this.$store.state.userName=response.data[1];
            this.$store.state.jogosultsag=response.data[2];
            console.log(this.$store.state.Uid),
            console.log(this.$store.state.userName),
            console.log(this.$store.state.jogosultsag)
        })
      })
    },
    refreshData(){
      if (this.$store.state.logged){
        document.getElementById("loginButton").innerHTML = "Logout"
      }else{
        document.getElementById("loginButton").innerHTML = "Login"
      }
    },
    openViewer() {
        var myModal = new bootstrap.Modal(document.getElementById("loginModal"), {
            keyboard: false,
        });
        myModal.show();
    },
  }
}

</script>

<style scoped>
.login {
  background-color: aliceblue;
}
</style>
