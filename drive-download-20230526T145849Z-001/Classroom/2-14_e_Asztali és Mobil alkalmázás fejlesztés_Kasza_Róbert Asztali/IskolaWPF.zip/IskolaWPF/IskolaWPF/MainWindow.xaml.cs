﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace IskolaWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        static List<string> stringLista = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
            StreamReader sr = new StreamReader("nevek.txt");
            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine(); // konzekvens minta: 2006;e;Kovacs Adam
                stringLista.Add(line);
            }
            sr.Close();
            listboxTanulok.ItemsSource = stringLista;
        }

        private void torlesButton_Click(object sender, RoutedEventArgs e)
        {
            if (listboxTanulok.SelectedItem != null)
            {
                stringLista.Remove(listboxTanulok.SelectedItem.ToString());
            } 
            else
            {
                MessageBox.Show("Nem jelölt ki tanulót!");
            }
            listboxTanulok.Items.Refresh();
        }

        private void mentesButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StreamWriter sw = new StreamWriter("nevekNEW.txt");
                foreach (string sor in stringLista)
                {
                    sw.WriteLine(sor);
                }
                sw.Close();
                MessageBox.Show("Sikeres mentés!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba mentés közben: " + ex.Message);
            }
            
        }
    }
}
