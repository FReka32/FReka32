﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Godrok
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Olvassa be és tárolja el a melyseg.txt fájl tartalmát! Írja ki a képernyőre, hogy az adatforrás hány adatot tartalmaz!
            List<int> melysegLista = new List<int>();
            StreamReader sr = new StreamReader("melyseg.txt");
            while (!sr.EndOfStream)
            {
                melysegLista.Add(Convert.ToInt32(sr.ReadLine()));
            }
            sr.Close();
            double adatokSzama = melysegLista.Count;
            Console.WriteLine("1. feladat");
            Console.WriteLine(adatokSzama);

            //2. Olvasson be egy távolságértéket, majd írja a képernyőre, hogy milyen mélyen van a gödör alja azon a helyen!Ezt a távolságértéket használja majd a 6.feladat megoldása során is !
            Console.Write("Adjon meg egy távolságértéket! ");
            int tavolsagErtek = Convert.ToInt32(Console.ReadLine());
            int godorMelysege = melysegLista[tavolsagErtek];
            Console.WriteLine("2. feladat");
            Console.WriteLine($"Ezen a helyen a felszín {godorMelysege} méter mélyen van.");

            //3. Határozza meg, hogy a felszín hány százaléka maradt érintetlen és jelenítse meg 2 tizedes pontossággal!
            double erintetlenFelszin = 0;
            List<int> godorIndexek = new List<int>();
            for (int i = 0; i < adatokSzama; i++)
            {
                if (melysegLista[i] == 0)
                {
                    erintetlenFelszin += 1;
                }
                else
                {
                    godorIndexek.Add(i);
                }
            }
            double erintetlenFelszinAranya = Math.Round((erintetlenFelszin / (adatokSzama / 100)), 2);
            Console.WriteLine("3. feladat");
            Console.WriteLine($"Az érintetlen terület aránya {erintetlenFelszinAranya}%.");

            //4.Írja ki a godrok.txt fájlba a gödrök leírását, azaz azokat a számsorokat, amelyek egy-egy gödör méterenkénti mélységét adják meg! Minden gödör leírása külön sorba kerüljön!Az állomány pontosan a gödrök számával egyező számú sort tartalmazzon!

            StreamWriter sw = new StreamWriter("godrok.txt");
            for (int i = 0; i < godorIndexek.Count; i++)
            {
                //sw.Write(godorIndexek[i]);
                Console.WriteLine(godorIndexek[i]);
                if(i!=0 && godorIndexek[i]- godorIndexek[i - 1] != 1)
                {
                    //sw.Write("\n");
                    Console.WriteLine("\n");
                }

            }
            sw.Close();
            Console.WriteLine("godrok.txt elkészült");
            /*int elozo = 0;
            Godor aktualisGodor = null;
            List<Godor> godrokLista = new List<Godor>();
            for (int i = 0; i < adatokSzama; i++)
            {
                if(elozo == 0 && melysegLista[i] != 0)
                {
                    aktualisGodor = new Godor(i);
                }
                if(elozo != 0 && melysegLista[i] == 0)
                {
                    godrokLista.Add(aktualisGodor);
                    aktualisGodor = null;
                }
                if(aktualisGodor != null)
                {
                    aktualisGodor.hozzaadmelyseg(melysegLista[i]);
                }
                elozo = melysegLista[i];
            }
            foreach (var item in godrokLista)
            {
                Console.WriteLine(item.kezdopont);
            }*/




            Console.ReadKey();
        }
    }
}
