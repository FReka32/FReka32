﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Reflection;

namespace Godrok
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Olvassa be és tárolja el a melyseg.txt fájl tartalmát! Írja ki a képernyőre, hogy az adatforrás hány adatot tartalmaz!
            List<int> melysegLista = new List<int>();
            StreamReader sr = new StreamReader("melyseg.txt");
            while (!sr.EndOfStream)
            {
                melysegLista.Add(Convert.ToInt32(sr.ReadLine()));
            }
            sr.Close();
            double adatokSzama = melysegLista.Count;
            Console.WriteLine("1. feladat");
            Console.WriteLine(adatokSzama);

            //2. Olvasson be egy távolságértéket, majd írja a képernyőre, hogy milyen mélyen van a gödör alja azon a helyen!Ezt a távolságértéket használja majd a 6.feladat megoldása során is !
            Console.Write("Adjon meg egy távolságértéket! ");
            int tavolsagErtek = Convert.ToInt32(Console.ReadLine());
            int godorMelysege = melysegLista[tavolsagErtek];
            Console.WriteLine("2. feladat");
            Console.WriteLine($"Ezen a helyen a felszín {godorMelysege} méter mélyen van.");

            //3. Határozza meg, hogy a felszín hány százaléka maradt érintetlen és jelenítse meg 2 tizedes pontossággal!
            double erintetlenFelszin = 0;
            List<int> godorIndexek = new List<int>();
            for (int i = 0; i < adatokSzama; i++)
            {
                if (melysegLista[i] == 0)
                {
                    erintetlenFelszin += 1;
                }
                else
                {
                    godorIndexek.Add(i);
                }
            }
            double erintetlenFelszinAranya = Math.Round((erintetlenFelszin / (adatokSzama / 100)), 2);
            Console.WriteLine("3. feladat");
            Console.WriteLine($"Az érintetlen terület aránya {erintetlenFelszinAranya}%.");

            //4.Írja ki a godrok.txt fájlba a gödrök leírását, azaz azokat a számsorokat, amelyek egy-egy gödör méterenkénti mélységét adják meg! Minden gödör leírása külön sorba kerüljön!Az állomány pontosan a gödrök számával egyező számú sort tartalmazzon!

            StreamWriter sw = new StreamWriter("godrok.txt");
            StreamWriter sw2 = new StreamWriter("godorindexek.txt");
            string egygodor = "";
            string egygodorindexek = "";

            for (int i = 0; i < godorIndexek.Count; i++)
            {  
                if(i!=0 && godorIndexek[i]- godorIndexek[i - 1] != 1)
                {
                    egygodor = egygodor.TrimEnd(' ');
                    egygodorindexek = egygodorindexek.TrimEnd(' ');
                    egygodor += "\n";
                    egygodorindexek += "\n";
                    sw.Write(egygodor);
                    sw2.Write(egygodorindexek);
                    egygodor = "";
                    egygodorindexek = "";
                }
                egygodor += melysegLista[godorIndexek[i]] + " ";
                egygodorindexek += godorIndexek[i] + " ";
            }
            if(egygodor != "")
            {
                sw.Write(egygodor.TrimEnd(' '));
            }
            if (egygodorindexek != "")
            {
                sw2.Write(egygodorindexek.TrimEnd(' '));
            }
            sw.Close();
            sw2.Close();
            Console.WriteLine("4. feladat");
            Console.WriteLine("godrok.txt elkészült");

            //5. Határozza meg a gödrök számát és írja a képernyőre!

            List<string> godorLista = new List<string>();
            StreamReader sr2 = new StreamReader("godrok.txt");
            int i2 = 0;
            while (!sr2.EndOfStream)
            {
                godorLista.Add(sr2.ReadLine());
                i2++;
            }
            sr2.Close();

            Console.WriteLine("5. feladat");
            Console.WriteLine($"A gödrök száma: {godorLista.Count()}");

            //6. Ha a 2. feladatban beolvasott helyen nincs gödör, akkor „Az adott helyen nincs gödör.” üzenetet jelenítse meg, ha ott gödör található, akkor határozza meg, hogy
            //    a) mi a gödör kezdő és végpontja!A meghatározott értékeket írja a képernyőre!
            //    (Ha nem tudja meghatározni, használja a további részfeladatoknál a 7 és 22
            //    értéket, mint a kezdő és a végpont helyét)
            //    b) a legmélyebb pontja felé mindkét irányból folyamatosan mélyül-e! Azaz a gödör
            //    az egyik szélétől monoton mélyül egy pontig, és onnantól monoton emelkedik a
            //    másik széléig. Az eredménytől függően írja ki a képernyőre a „Nem mélyül
            //    folyamatosan.” vagy a „Folyamatosan mélyül.” mondatot!
            //    c) mekkora a legnagyobb mélysége!A meghatározott értéket írja a képernyőre!
            //    d) mekkora a térfogata, ha szélessége minden helyen 10 méternyi! A meghatározott
            //    értéket írja a képernyőre!
            //    e) a félkész csatorna esőben jelentős mennyiségű vizet fogad be.Egy gödör annyi
            //    vizet képes befogadni anélkül, hogy egy nagyobb szélvihar hatására se öntsön
            //    ki, amennyi esetén a víz felszíne legalább 1 méter mélyen van a külső felszínhez
            //    képest.Írja a képernyőre ezt a vízmennyiséget!

            Console.WriteLine("6. feladat");
            List<string> godorIndexekLista = new List<string>();
            StreamReader sr3 = new StreamReader("godorindexek.txt");
            int i3 = 0;
            while (!sr3.EndOfStream)
            {
                godorIndexekLista.Add(sr3.ReadLine());
                i3++;
            }
            sr2.Close();


            bool kereses_kesz = false;
            string uzenet_a = "Az adott helyen nincs gödör.";
            foreach (var item in godorIndexekLista)
            {
                string[] indexek = item.Split(' ');
                foreach (string key in indexek)
                {  
                    if (key == tavolsagErtek.ToString())
                    {
                        uzenet_a = $"A gödör kezdete: {Convert.ToInt32(indexek.First())+1} méter, a gödör vége: {Convert.ToInt32(indexek.Last())+1} méter.";
                        kereses_kesz = true;
                        break;
                    }
                }
                if (kereses_kesz)
                {
                    break;
                }
            }
            
            Console.WriteLine("a)");
            Console.WriteLine(uzenet_a);
            /*Console.WriteLine("b)");
            Console.WriteLine($"Nem mélyül folyamatosan.");
            Console.WriteLine("c)");
            Console.WriteLine($"A legnagyobb mélysége {} méter.");
            Console.WriteLine("d)");
            Console.WriteLine($"A térfogata {} m ^ 3.");
            Console.WriteLine("e)");
            Console.WriteLine($"A vízmennyiség {} m ^ 3.");*/

            Console.ReadKey();
        }
    }
}
