﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Iskola;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iskola.Tests
{
    [TestClass()]
    public class TanuloTests
    {
        [TestMethod()]
        public void getAzonositoTest()
        {
            string tesztString = "2005;b;Fialowski Pal";
            string[] tesztAdat = tesztString.Split(';');
            Assert.AreEqual("6cbodszi", Tanulo.getAzonosito(tesztAdat));
            string tesztString2 = "2006;c;Krizsan Vivien Evelin";
            string[] tesztAdat2 = tesztString2.Split(';');
            Assert.AreEqual("6ckriviv", Tanulo.getAzonosito(tesztAdat2));
            Assert.AreNotEqual("6cKriViv", Tanulo.getAzonosito(tesztAdat2));
            Assert.AreNotEqual("06ckriviv", Tanulo.getAzonosito(tesztAdat2));
            Assert.AreNotEqual("06ckriviva", Tanulo.getAzonosito(tesztAdat2));
        }
    }
}