﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Iskola
{
    public class Program
    {
        static List<Tanulo> tanulokLista = new List<Tanulo>();
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("nevek.txt");
            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine(); // konzekvens minta: 2006;e;Kovacs Adam
                Tanulo tanulo = new Tanulo(line);
                tanulokLista.Add(tanulo);
            }
            sr.Close();

            Console.WriteLine("3.feladat");
            Console.WriteLine("Tanulók adatai:");
            foreach (Tanulo tanulo in tanulokLista)
            {
                Console.WriteLine($"név: {tanulo.Nev} osztály: {tanulo.OsztalyBetujele} kezdés éve: {tanulo.KezdesEve}");
            }

            Console.WriteLine($"Hány tanuló jár az iskolába: {tanulokLista.Count()}");

            Console.WriteLine("4. feladat");
            Console.WriteLine($"Első tanuló azonosítója: {tanulokLista.First().Azonosito}");
            Console.WriteLine($"Utolsó tanuló azonosítója: {tanulokLista.Last().Azonosito}");

            StreamWriter sw = new StreamWriter("azonositok.txt");
            foreach (Tanulo tanulo in tanulokLista)
            {
                sw.WriteLine($"{tanulo.Nev} {tanulo.Azonosito}");
            }
            sw.Close();
            Console.ReadKey();
        }
    }
}
