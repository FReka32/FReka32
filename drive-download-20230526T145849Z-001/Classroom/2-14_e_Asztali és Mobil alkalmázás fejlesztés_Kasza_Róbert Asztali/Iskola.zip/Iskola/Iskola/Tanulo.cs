﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iskola
{
    public class Tanulo
    {
        public int KezdesEve { get; private set; }
        public string OsztalyBetujele { get; private set; }
        public string Nev { get; private set; }
        public string Azonosito { get; private set; }

        public Tanulo(string adatsor)
        {
            string[] adatok = adatsor.Split(';');
            KezdesEve = Convert.ToInt32(adatok[0]);
            OsztalyBetujele = adatok[1];
            Nev = adatok[2];
            Azonosito = getAzonosito(adatok);
        }
        public static string getAzonosito(string[] data)
        {
            string ret = "";
            //evfolyam utolso szamjegye
            ret += data[0][3];
            //osztaly betujele
            ret += data[1];
            string[] teljesNev = data[2].Split(' ');
            //vezeteknev es keresztnev ("elso" és "masodik" nev) elso harom karaktere
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (Char.IsLower(teljesNev[i][j]))
                    {
                        ret += teljesNev[i][j];
                    }
                    else
                    {
                        ret += Char.ToLower(teljesNev[i][j]);
                    }
                }
            }
            
            return ret;
        }
    }
}
