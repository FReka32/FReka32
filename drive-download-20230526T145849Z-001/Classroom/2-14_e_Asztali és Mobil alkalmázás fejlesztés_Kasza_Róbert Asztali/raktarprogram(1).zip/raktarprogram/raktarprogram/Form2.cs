﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace raktarprogram
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            List<Termek> termekek = new List<Termek>();
            StreamReader sr = new StreamReader("termekek.txt");
            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] darabok = sor.Split(';');
                Termek egyTermek = new Termek(darabok[0], darabok[1]);
                termekek.Add(egyTermek);
            }
            termektablazat.DataSource = termekek;
            sr.Close();
        }
    }
}
