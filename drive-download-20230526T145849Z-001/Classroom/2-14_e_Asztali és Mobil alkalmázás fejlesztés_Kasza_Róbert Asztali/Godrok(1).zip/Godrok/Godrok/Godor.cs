﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//oran megosztott osztaly
namespace Godrok
{
    class Godor
    {
        public List<int> melysegek = new List<int>();
        public int kezdopont;
        public int vegpont;

        public Godor(int kezdopont)
        {
            this.kezdopont = kezdopont;
        }
        public void hozzaadmelyseg(int melyseg)
        {
            melysegek.Add(melyseg);
        }
    }
}
